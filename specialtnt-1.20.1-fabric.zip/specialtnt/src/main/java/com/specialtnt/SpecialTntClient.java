package com.specialtnt;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;

import java.util.Random;

public class SpecialTntClient implements ClientModInitializer {
    public static int flash = 0;
    private static final Random RNG = new Random();
    private static final String CHARS = "01ABCDEF";

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(SpecialTntMod.TNT_ENTITY, SpecialTntRenderer::new);

        ClientPlayNetworking.registerGlobalReceiver(SpecialTntMod.FLASH_PACKET, (client, handler, buf, sender) -> {
            int d = buf.readInt();
            client.execute(() -> flash = Math.max(flash, d));
        });

        ClientTickEvents.END_CLIENT_TICK.register(c -> { if (flash > 0) flash--; });

        HudRenderCallback.EVENT.register((ctx, delta) -> {
            if (flash <= 0) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            int w = mc.getWindow().getScaledWidth();
            int h = mc.getWindow().getScaledHeight();
            boolean on = (flash / 2) % 2 == 0;
            ctx.fill(0, 0, w, h, on ? 0x6600FF41 : 0x2200FF41);
            for (int i = 0; i < 80; i++) {
                String s = String.valueOf(CHARS.charAt(RNG.nextInt(CHARS.length())));
                ctx.drawText(mc.textRenderer, s, RNG.nextInt(w), RNG.nextInt(h), 0xFF00FF41, false);
            }
        });
    }
}
