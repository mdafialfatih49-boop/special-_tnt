package com.specialtnt;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class SpecialTntEntity extends Entity {
    private static final TrackedData<Integer> FUSE =
            net.minecraft.entity.data.DataTracker.registerData(SpecialTntEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TYPE =
            net.minecraft.entity.data.DataTracker.registerData(SpecialTntEntity.class, TrackedDataHandlerRegistry.INTEGER);

    private LivingEntity causingEntity;
    public float power = 2.5f;

    public SpecialTntEntity(EntityType<?> type, World world) {
        super(type, world);
        this.intersectionChecked = true;
    }

    public SpecialTntEntity(World world, double x, double y, double z, LivingEntity igniter, TntType t) {
        this(SpecialTntMod.TNT_ENTITY, world);
        if (t == TntType.BLACK_HOLE) y += 0.5;
        setPosition(x, y, z);
        double d = world.random.nextDouble() * 6.2831855;
        setVelocity(-Math.sin(d) * 0.02, 0.2, -Math.cos(d) * 0.02);
        if (t == TntType.BETTY) setVelocity(0, 0.85, 0);
        if (t == TntType.CLUSTER) setVelocity(0, 1.0, 0);
        if (t == TntType.BLACK_HOLE) { setNoGravity(true); setVelocity(Vec3d.ZERO); }
        this.prevX = x; this.prevY = y; this.prevZ = z;
        this.causingEntity = igniter;
        setTntType(t);
        setFuse(t.fuse);
    }

    @Override
    protected void initDataTracker() {
        dataTracker.startTracking(FUSE, 80);
        dataTracker.startTracking(TYPE, 0);
    }

    public int getFuse() { return dataTracker.get(FUSE); }
    public void setFuse(int f) { dataTracker.set(FUSE, f); }
    public TntType getTntType() { return TntType.byOrdinal(dataTracker.get(TYPE)); }
    public void setTntType(TntType t) { dataTracker.set(TYPE, t.ordinal()); }

    public BlockState getBlockState() {
        TntType t = getTntType();
        return t.hasBlock ? SpecialTntMod.BLOCKS.get(t).getDefaultState() : Blocks.TNT.getDefaultState();
    }

    @Override
    protected boolean canClimb() { return false; }

    @Override
    public boolean canHit() { return !isRemoved(); }

    @Override
    public Packet<ClientPlayPacketListener> createSpawnPacket() { return new EntitySpawnS2CPacket(this); }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        setFuse(nbt.getShort("Fuse"));
        setTntType(TntType.byOrdinal(nbt.getInt("TntType")));
        if (nbt.contains("Power")) power = nbt.getFloat("Power");
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putShort("Fuse", (short) getFuse());
        nbt.putInt("TntType", getTntType().ordinal());
        nbt.putFloat("Power", power);
    }

    @Override
    public void tick() {
        World world = getWorld();
        if (!hasNoGravity()) setVelocity(getVelocity().add(0, -0.04, 0));
        move(MovementType.SELF, getVelocity());
        setVelocity(getVelocity().multiply(0.98));
        if (isOnGround()) setVelocity(getVelocity().multiply(0.7, -0.5, 0.7));

        int f = getFuse() - 1;
        setFuse(f);
        if (f <= 0) {
            discard();
            if (world instanceof ServerWorld sw) explode(sw);
        } else if (world instanceof ServerWorld sw) {
            duringFuse(sw, f);
        } else {
            world.addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.7, getZ(), 0, 0, 0);
        }
    }

    private void sound(ServerWorld w, net.minecraft.sound.SoundEvent s, float vol, float pitch) {
        w.playSound(null, getX(), getY(), getZ(), s, SoundCategory.BLOCKS, vol, pitch);
    }

    // ---------------------------------------------------------------- sumbu
    private void duringFuse(ServerWorld sw, int f) {
        TntType t = getTntType();
        boolean first = f == t.fuse - 1;
        switch (t) {
            case BLACK_HOLE -> {
                Vec3d c = getPos();
                if (f % 10 == 0) sound(sw, SoundEvents.BLOCK_BEACON_AMBIENT, 4f, 0.5f);
                sw.spawnParticles(ParticleTypes.REVERSE_PORTAL, c.x, c.y, c.z, 30, 3, 3, 3, 0.3);
                sw.spawnParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 30, 1, 1, 1, 1.5);
                for (Entity e : sw.getOtherEntities(this, new Box(c, c).expand(25),
                        en -> !(en instanceof PlayerEntity p && p.isSpectator()))) {
                    Vec3d d = c.subtract(e.getPos().add(0, e.getHeight() / 2, 0));
                    double dist = d.length();
                    if (dist < 0.8) continue;
                    Vec3d pull = d.normalize().multiply(Math.min(1.2, 0.08 + 1.5 / dist));
                    e.setVelocity(e.getVelocity().multiply(0.85).add(pull));
                    e.velocityModified = true;
                    e.fallDistance = 0;
                }
                if (f % 3 == 0) {
                    BlockPos bp = getBlockPos();
                    for (int i = 0; i < 15; i++) {
                        BlockPos p = bp.add(sw.random.nextBetween(-10, 10), sw.random.nextBetween(-6, 8), sw.random.nextBetween(-10, 10));
                        BlockState s = sw.getBlockState(p);
                        if (!s.isAir() && s.getFluidState().isEmpty() && s.getHardness(sw, p) >= 0 && sw.getBlockEntity(p) == null) {
                            FallingBlockEntity fb = FallingBlockEntity.spawnFromBlock(sw, p, s);
                            fb.dropItem = false;
                        }
                    }
                }
            }
            case GLITCH -> {
                if (first) {
                    for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(this) < 40 * 40)) {
                        var buf = PacketByteBufs.create();
                        buf.writeInt(t.fuse + 10);
                        ServerPlayNetworking.send(p, SpecialTntMod.FLASH_PACKET, buf);
                    }
                }
                sw.spawnParticles(ParticleTypes.COMPOSTER, getX(), getY() + 1, getZ(), 6, 1.5, 1.5, 1.5, 0.1);
                if (f % 4 == 0) sound(sw, SoundEvents.BLOCK_NOTE_BLOCK_BIT.value(), 2f, 0.5f + sw.random.nextFloat() * 1.5f);
            }
            case CRYO -> {
                sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY() + 0.5, getZ(), 8, 2, 0.5, 2, 0.02);
                sw.spawnParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1, getZ(), 8, 2, 1.5, 2, 0.02);
                if (f % 15 == 0) sound(sw, SoundEvents.BLOCK_GLASS_BREAK, 2f, 0.6f);
            }
            case NUKE -> {
                if (f % 5 == 0) sound(sw, SoundEvents.BLOCK_NOTE_BLOCK_BIT.value(), 4f, (f / 5) % 2 == 0 ? 1.2f : 0.7f);
                sw.spawnParticles(ParticleTypes.SNEEZE, getX(), getY() + 1, getZ(), 3, 0.5, 0.5, 0.5, 0.02);
            }
            case BETTY -> {
                if (first) {
                    sound(sw, SoundEvents.ENTITY_SLIME_JUMP, 2f, 1.8f);
                    sw.spawnParticles(ParticleTypes.CLOUD, getX(), getY(), getZ(), 15, 0.4, 0.1, 0.4, 0.05);
                }
            }
            case BUILD -> {
                sw.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 0.8, getZ(), 6, 0.5, 0.5, 0.5, 0.05);
                sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 0.8, getZ(), 4, 0.4, 0.4, 0.4, 0.03);
                if (f % 10 == 0) sound(sw, SoundEvents.BLOCK_PISTON_EXTEND, 1.5f, 0.8f);
            }
            case CLUSTER -> {
                if (first) sound(sw, SoundEvents.ENTITY_FIREWORK_ROCKET_LAUNCH, 3f, 1f);
                sw.spawnParticles(ParticleTypes.FIREWORK, getX(), getY(), getZ(), 4, 0.1, 0.1, 0.1, 0.02);
            }
            case MINI -> sw.spawnParticles(ParticleTypes.ELECTRIC_SPARK, getX(), getY() + 0.5, getZ(), 1, 0.1, 0.1, 0.1, 0.01);
        }
    }

    // -------------------------------------------------------------- ledakan
    private void explode(ServerWorld sw) {
        TntType t = getTntType();
        double x = getX(), y = getY(), z = getZ();
        BlockPos pos = getBlockPos();
        switch (t) {
            case BLACK_HOLE -> {
                sound(sw, SoundEvents.ENTITY_GENERIC_EXPLODE, 4f, 0.4f);
                sw.createExplosion(this, x, y, z, 8f, World.ExplosionSourceType.TNT);
            }
            case GLITCH -> {
                for (ServerPlayerEntity p : sw.getPlayers(pl -> pl.squaredDistanceTo(this) < 40 * 40)) {
                    var buf = PacketByteBufs.create();
                    buf.writeInt(15);
                    ServerPlayNetworking.send(p, SpecialTntMod.FLASH_PACKET, buf);
                }
                sound(sw, SoundEvents.ENTITY_ENDERMAN_TELEPORT, 4f, 0.5f);
                sw.spawnParticles(ParticleTypes.COMPOSTER, x, y + 1, z, 200, 7, 7, 7, 0.1);
                TntEffects.glitch(sw, pos);
            }
            case CRYO -> {
                sound(sw, SoundEvents.BLOCK_GLASS_BREAK, 4f, 0.5f);
                sound(sw, SoundEvents.BLOCK_AMETHYST_BLOCK_BREAK, 4f, 0.5f);
                sw.spawnParticles(ParticleTypes.CLOUD, x, y + 1, z, 300, 8, 4, 8, 0.05);
                sw.spawnParticles(ParticleTypes.SNOWFLAKE, x, y + 1, z, 300, 8, 4, 8, 0.1);
                TntEffects.freeze(sw, pos, causingEntity);
            }
            case NUKE -> {
                sw.createExplosion(this, x, y, z, 8f, World.ExplosionSourceType.TNT);
                for (int i = 0; i < 8; i++) {
                    SpecialTntEntity c = new SpecialTntEntity(sw, x, y, z, causingEntity, TntType.MINI);
                    c.power = 4f;
                    c.setFuse(5 + sw.random.nextInt(25));
                    c.setVelocity((sw.random.nextDouble() - 0.5) * 1.2, 0.3 + sw.random.nextDouble() * 0.5, (sw.random.nextDouble() - 0.5) * 1.2);
                    sw.spawnEntity(c);
                }
                for (int dy = 0; dy < 4; dy++) {
                    AreaEffectCloudEntity cloud = new AreaEffectCloudEntity(sw, x, y + dy - 1, z);
                    cloud.setRadius(10f);
                    cloud.setDuration(2400);
                    cloud.setWaitTime(0);
                    cloud.setRadiusOnUse(0f);
                    cloud.setRadiusGrowth(0f);
                    cloud.setParticleType(ParticleTypes.SNEEZE);
                    cloud.addEffect(new StatusEffectInstance(StatusEffects.WITHER, 100, 0));
                    cloud.addEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 100, 0));
                    sw.spawnEntity(cloud);
                }
            }
            case BETTY -> {
                sw.createExplosion(this, x, y, z, 4.5f, World.ExplosionSourceType.TNT);
                for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(6), LivingEntity::isAlive)) {
                    e.damage(sw.getDamageSources().explosion(this, causingEntity), 8f);
                }
            }
            case BUILD -> {
                sound(sw, SoundEvents.BLOCK_ANVIL_USE, 3f, 0.7f);
                sw.spawnParticles(ParticleTypes.FLASH, x, y + 1, z, 5, 1, 1, 1, 0);
                sw.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y + 1, z, 100, 3, 2, 3, 0.1);
                TntEffects.build(sw, pos);
            }
            case CLUSTER -> {
                sound(sw, SoundEvents.ENTITY_FIREWORK_ROCKET_BLAST, 4f, 1f);
                sound(sw, SoundEvents.ENTITY_FIREWORK_ROCKET_TWINKLE, 4f, 1f);
                sw.spawnParticles(ParticleTypes.FIREWORK, x, y, z, 100, 1, 1, 1, 0.3);
                for (int i = 0; i < 60; i++) {
                    DustParticleEffect dust = new DustParticleEffect(new Vector3f(sw.random.nextFloat(), sw.random.nextFloat(), sw.random.nextFloat()), 1.6f);
                    sw.spawnParticles(dust, x, y, z, 3, 2, 2, 2, 0.5);
                }
                for (int i = 0; i < 30; i++) {
                    SpecialTntEntity c = new SpecialTntEntity(sw, x, y, z, causingEntity, TntType.MINI);
                    c.setFuse(30 + sw.random.nextInt(40));
                    c.setVelocity((sw.random.nextDouble() * 2 - 1) * 1.2, 0.2 + sw.random.nextDouble() * 0.4, (sw.random.nextDouble() * 2 - 1) * 0.8);
                    sw.spawnEntity(c);
                }
            }
            case MINI -> sw.createExplosion(this, x, y, z, power, World.ExplosionSourceType.TNT);
        }
    }
}
