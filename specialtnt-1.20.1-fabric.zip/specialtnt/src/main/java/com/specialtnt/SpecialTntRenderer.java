package com.specialtnt;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.TntMinecartEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

public class SpecialTntRenderer extends EntityRenderer<SpecialTntEntity> {
    private final BlockRenderManager blockRenderManager;

    public SpecialTntRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.5f;
        this.blockRenderManager = ctx.getBlockRenderManager();
    }

    @Override
    public void render(SpecialTntEntity e, float yaw, float tickDelta, MatrixStack m, VertexConsumerProvider vc, int light) {
        m.push();
        m.translate(0.0, 0.5, 0.0);
        int i = e.getFuse();
        if ((float) i - tickDelta + 1.0f < 10.0f) {
            float f = 1.0f - ((float) i - tickDelta + 1.0f) / 10.0f;
            f = MathHelper.clamp(f, 0.0f, 1.0f);
            f *= f;
            f *= f;
            float g = 1.0f + f * 0.3f;
            m.scale(g, g, g);
        }
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-90.0f));
        m.translate(-0.5, -0.5, 0.5);
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0f));
        TntMinecartEntityRenderer.renderFlashingBlock(blockRenderManager, e.getBlockState(), m, vc, light, i / 5 % 2 == 0);
        m.pop();
        super.render(e, yaw, tickDelta, m, vc, light);
    }

    @Override
    public Identifier getTexture(SpecialTntEntity entity) {
        return PlayerScreenHandler.BLOCK_ATLAS_TEXTURE;
    }
}
