package com.specialtnt;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.MapColor;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class SpecialTntBlock extends Block {
    public final TntType type;

    public SpecialTntBlock(TntType type) {
        super(AbstractBlock.Settings.create().mapColor(MapColor.BRIGHT_RED).breakInstantly()
                .sounds(BlockSoundGroup.GRASS).burnable());
        this.type = type;
    }

    @Override
    public void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        if (oldState.isOf(state.getBlock())) return;
        if (world.isReceivingRedstonePower(pos)) {
            prime(world, pos, null);
            world.removeBlock(pos, false);
        } else if (type == TntType.BETTY && !world.isClient) {
            world.scheduleBlockTick(pos, this, 60); // 3 detik waktu arming
        }
    }

    @Override
    public void neighborUpdate(BlockState state, World world, BlockPos pos, Block source, BlockPos sourcePos, boolean notify) {
        if (world.isReceivingRedstonePower(pos)) {
            prime(world, pos, null);
            world.removeBlock(pos, false);
        }
    }

    @Override
    public void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (type != TntType.BETTY) return;
        Box box = new Box(pos).expand(4);
        if (!world.getEntitiesByClass(LivingEntity.class, box, e -> e.isAlive() && !e.isSpectator()).isEmpty()) {
            prime(world, pos, null);
            world.removeBlock(pos, false);
        } else {
            world.scheduleBlockTick(pos, this, 5);
        }
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        ItemStack s = player.getStackInHand(hand);
        if (!s.isOf(Items.FLINT_AND_STEEL) && !s.isOf(Items.FIRE_CHARGE)) {
            return super.onUse(state, world, pos, player, hand, hit);
        }
        prime(world, pos, player);
        world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_ALL | Block.REDRAW_ON_MAIN_THREAD);
        if (!player.isCreative()) {
            if (s.isOf(Items.FLINT_AND_STEEL)) s.damage(1, player, p -> p.sendToolBreakStatus(hand));
            else s.decrement(1);
        }
        return ActionResult.success(world.isClient);
    }

    @Override
    public void onProjectileHit(World world, BlockState state, BlockHitResult hit, ProjectileEntity projectile) {
        if (!world.isClient && projectile.isOnFire()) {
            BlockPos p = hit.getBlockPos();
            Entity owner = projectile.getOwner();
            prime(world, p, owner instanceof LivingEntity l ? l : null);
            world.removeBlock(p, false);
        }
    }

    @Override
    public void onDestroyedByExplosion(World world, BlockPos pos, Explosion explosion) {
        if (world.isClient) return;
        SpecialTntEntity e = new SpecialTntEntity(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5,
                explosion.getCausingEntity(), type);
        int f = Math.max(4, e.getFuse());
        e.setFuse(world.random.nextInt(f / 4) + f / 8);
        world.spawnEntity(e);
    }

    @Override
    public boolean shouldDropItemsOnExplosion(Explosion explosion) {
        return false;
    }

    public static void prime(World world, BlockPos pos, LivingEntity igniter) {
        if (world.isClient) return;
        SpecialTntBlock b = (SpecialTntBlock) world.getBlockState(pos).getBlock();
        SpecialTntEntity e = new SpecialTntEntity(world, pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, igniter, b.type);
        world.spawnEntity(e);
        world.playSound(null, e.getX(), e.getY(), e.getZ(), SoundEvents.ENTITY_TNT_PRIMED, SoundCategory.BLOCKS, 1f, 1f);
        world.emitGameEvent(igniter, GameEvent.PRIME_FUSE, pos);
    }
}
