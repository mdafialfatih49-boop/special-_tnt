package com.specialtnt;

public enum TntType {
    BLACK_HOLE("black_hole_tnt", 80, true),
    GLITCH("glitch_tnt", 60, true),
    CRYO("cryo_freeze_tnt", 60, true),
    NUKE("nuclear_lite_tnt", 100, true),
    BETTY("bouncing_betty_tnt", 15, true),
    BUILD("build_o_matic_tnt", 50, true),
    CLUSTER("cluster_party_tnt", 18, true),
    MINI("mini_tnt", 40, false);

    public final String id;
    public final int fuse;
    public final boolean hasBlock;

    TntType(String id, int fuse, boolean hasBlock) {
        this.id = id;
        this.fuse = fuse;
        this.hasBlock = hasBlock;
    }

    public static TntType byOrdinal(int i) {
        TntType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
