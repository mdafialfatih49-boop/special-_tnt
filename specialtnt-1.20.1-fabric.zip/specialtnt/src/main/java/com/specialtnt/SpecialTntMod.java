package com.specialtnt;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.EnumMap;
import java.util.Map;

public class SpecialTntMod implements ModInitializer {
    public static final String MODID = "specialtnt";
    public static final Identifier FLASH_PACKET = new Identifier(MODID, "glitch_flash");
    public static final Map<TntType, Block> BLOCKS = new EnumMap<>(TntType.class);
    public static EntityType<SpecialTntEntity> TNT_ENTITY;

    @Override
    public void onInitialize() {
        for (TntType t : TntType.values()) {
            if (!t.hasBlock) continue;
            Identifier id = new Identifier(MODID, t.id);
            Block b = Registry.register(Registries.BLOCK, id, new SpecialTntBlock(t));
            Registry.register(Registries.ITEM, id, new BlockItem(b, new Item.Settings()));
            BLOCKS.put(t, b);
        }

        TNT_ENTITY = Registry.register(Registries.ENTITY_TYPE, new Identifier(MODID, "special_tnt"),
                EntityType.Builder.<SpecialTntEntity>create(SpecialTntEntity::new, SpawnGroup.MISC)
                        .makeFireImmune().setDimensions(0.98f, 0.98f)
                        .maxTrackingRange(10).trackingTickInterval(2)
                        .build("special_tnt"));

        Registry.register(Registries.ITEM_GROUP, new Identifier(MODID, "special_tnt"),
                FabricItemGroup.builder()
                        .icon(() -> new ItemStack(BLOCKS.get(TntType.BLACK_HOLE)))
                        .displayName(Text.translatable("itemGroup.specialtnt"))
                        .entries((ctx, entries) -> {
                            for (TntType t : TntType.values()) {
                                if (t.hasBlock) entries.add(BLOCKS.get(t));
                            }
                        }).build());
    }
}
