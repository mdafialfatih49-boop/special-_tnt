package com.specialtnt;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

import java.util.List;

public final class TntEffects {
    private TntEffects() {}

    private static final Block[] RANDOM_BLOCKS = {
            Blocks.SAND, Blocks.GRAVEL, Blocks.GLASS, Blocks.MAGMA_BLOCK, Blocks.NETHERRACK,
            Blocks.OBSIDIAN, Blocks.PURPLE_WOOL, Blocks.LIME_WOOL, Blocks.SLIME_BLOCK,
            Blocks.TNT, Blocks.GLOWSTONE, Blocks.COBWEB, Blocks.HAY_BLOCK, Blocks.SOUL_SAND
    };

    private static final List<EntityType<?>> MOBS = List.of(
            EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.PIG, EntityType.COW,
            EntityType.SHEEP, EntityType.CHICKEN, EntityType.SPIDER, EntityType.VILLAGER, EntityType.SLIME,
            EntityType.ENDERMAN, EntityType.WOLF, EntityType.HORSE, EntityType.WITCH, EntityType.BLAZE);

    /** Glitch / Matrix: acak blok dan mob dalam radius 15. */
    public static void glitch(ServerWorld w, BlockPos c) {
        Random r = w.random;
        int R = 15;
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++) {
            if (x * x + y * y + z * z > R * R) continue;
            p.set(c.getX() + x, c.getY() + y, c.getZ() + z);
            if (p.getY() < w.getBottomY() || p.getY() >= w.getTopY()) continue;
            BlockState s = w.getBlockState(p);
            if (s.isAir() || s.getHardness(w, p) < 0 || w.getBlockEntity(p) != null) continue;
            Block b = s.getBlock();
            BlockState ns = null;
            if (b == Blocks.STONE) ns = Blocks.SAND.getDefaultState();
            else if (b == Blocks.GRASS_BLOCK) ns = r.nextBoolean() ? Blocks.WATER.getDefaultState() : Blocks.LAVA.getDefaultState();
            else if (r.nextFloat() < 0.35f) ns = RANDOM_BLOCKS[r.nextInt(RANDOM_BLOCKS.length)].getDefaultState();
            if (ns != null) w.setBlockState(p, ns, Block.NOTIFY_LISTENERS);
        }
        Box box = new Box(c).expand(R);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, box,
                en -> !(en instanceof PlayerEntity) && !(en instanceof ArmorStandEntity)
                        && en.squaredDistanceTo(c.getX(), c.getY(), c.getZ()) <= R * R)) {
            Entity n = MOBS.get(r.nextInt(MOBS.size())).create(w);
            if (n == null) continue;
            n.refreshPositionAndAngles(e.getX(), e.getY(), e.getZ(), e.getYaw(), e.getPitch());
            e.discard();
            w.spawnEntity(n);
        }
    }

    /** Cryo-Freeze: tanpa kerusakan, membekukan radius 20. */
    public static void freeze(ServerWorld w, BlockPos c, LivingEntity igniter) {
        Random r = w.random;
        int R = 20;
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int x = -R; x <= R; x++) for (int y = -R; y <= R; y++) for (int z = -R; z <= R; z++) {
            if (x * x + y * y + z * z > R * R) continue;
            p.set(c.getX() + x, c.getY() + y, c.getZ() + z);
            if (p.getY() < w.getBottomY() || p.getY() >= w.getTopY()) continue;
            BlockState s = w.getBlockState(p);
            if (s.isAir()) {
                BlockPos below = p.down();
                if (r.nextFloat() < 0.25f && w.getBlockState(below).isFullCube(w, below)) {
                    w.setBlockState(p, Blocks.POWDER_SNOW.getDefaultState(), Block.NOTIFY_LISTENERS);
                }
            } else if (s.isOf(Blocks.WATER)) {
                w.setBlockState(p, Blocks.ICE.getDefaultState(), Block.NOTIFY_LISTENERS);
            } else if (s.getHardness(w, p) >= 0 && w.getBlockEntity(p) == null && s.isFullCube(w, p)) {
                boolean exposed = false;
                for (Direction d : Direction.values()) {
                    if (w.getBlockState(p.offset(d)).isAir()) { exposed = true; break; }
                }
                if (exposed) w.setBlockState(p, Blocks.PACKED_ICE.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(c).expand(R),
                en -> en != igniter && en.squaredDistanceTo(c.getX(), c.getY(), c.getZ()) <= R * R)) {
            e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 400, 4));
            e.setFrozenTicks(300);
        }
    }

    /** Build-O-Matic: benteng kecil 7x7, tinggi 4. */
    public static void build(ServerWorld w, BlockPos c) {
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -1; dy <= 4; dy++) {
            p.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
            if (p.getY() < w.getBottomY() || p.getY() >= w.getTopY()) continue;
            boolean wall = Math.abs(dx) == 3 || Math.abs(dz) == 3;
            boolean corner = Math.abs(dx) == 3 && Math.abs(dz) == 3;
            BlockState s;
            if (dy == -1) s = Blocks.SMOOTH_STONE.getDefaultState();
            else if (dy == 4) s = Blocks.OBSIDIAN.getDefaultState();
            else if (corner) s = Blocks.OBSIDIAN.getDefaultState();
            else if (wall) {
                if (dz == 3 && dx == 0 && dy <= 1) s = Blocks.AIR.getDefaultState();            // pintu masuk
                else if (dy == 2 && (dx == 0 || dz == 0)) s = Blocks.IRON_BARS.getDefaultState(); // jendela
                else s = Blocks.STONE_BRICKS.getDefaultState();
            } else if (dx == 0 && dz == 0 && dy == 3) s = Blocks.SEA_LANTERN.getDefaultState();
            else s = Blocks.AIR.getDefaultState();
            w.setBlockState(p, s, Block.NOTIFY_ALL);
        }
    }
}
